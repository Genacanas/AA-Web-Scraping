# How to Run

**Prerequisites**
- Python 3.10+ and `pip`
- Install deps:
  ```bash
  pip install -r requirements.txt
  python get_structure.py --out output/topic_structure.json